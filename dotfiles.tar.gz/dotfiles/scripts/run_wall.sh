#!/bin/bash
bash /home/bleezie/scripts/switch_wallpaper.sh
